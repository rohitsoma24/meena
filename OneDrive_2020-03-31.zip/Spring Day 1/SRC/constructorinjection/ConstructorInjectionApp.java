package com.mphasis.springday1.constructorinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ConstructorInjectionApp {

	public static void main(String[] args) {
	
		 ApplicationContext context = new ClassPathXmlApplicationContext("/com/mphasis/springday1/constructorinjection/config.xml");

		 Student student1 = context.getBean("student1",Student.class);
		 
		 System.out.println(student1);
	}

}
