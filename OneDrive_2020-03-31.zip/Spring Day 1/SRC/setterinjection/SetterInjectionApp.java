package com.mphasis.springday1.setterinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SetterInjectionApp {

	public static void main(String[] args) {
		
		 ApplicationContext context = new ClassPathXmlApplicationContext("/com/mphasis/springday1/setterinjection/config.xml");
		 
		 Student student1 = context.getBean("student1",Student.class);
		 System.out.println(student1);
	}

}
