package com.mphasis.springday1.setterinjection;

public class Student {

	private int id;
	private String name;
	
	
	
	public void setId(int id) {
		this.id = id;
	}



	public void setName(String name) {
		this.name = name;
	}



	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}
	
	
	
	

}
