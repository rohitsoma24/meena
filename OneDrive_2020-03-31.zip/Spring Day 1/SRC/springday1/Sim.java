package com.mphasis.springday1;

public interface Sim {

	void calling();
	void data();
}
