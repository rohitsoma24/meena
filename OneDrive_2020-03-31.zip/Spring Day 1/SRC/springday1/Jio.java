package com.mphasis.springday1;

public class Jio implements Sim {

	public void calling() {
		// TODO Auto-generated method stub
		
	}

	public void data() {
		// TODO Auto-generated method stub
		
	}

}
