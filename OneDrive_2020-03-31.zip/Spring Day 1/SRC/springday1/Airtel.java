package com.mphasis.springday1;

public class Airtel implements Sim {

	
	public Airtel() {
	
		System.out.println("Airtel class Default Constructor is called..");
	}
	
	public void calling() {
		
		System.out.println("Calling from Airtel N/W");
	}

	public void data() {
		
		System.out.println("Using data of Airtel N/W");
	}

}
