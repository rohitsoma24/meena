package com.mphasis.springday1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringApp 
{
    public static void main( String[] args )
    {
//        Sim sim = new Airtel();
//        sim.calling();
//        sim.data();
    	
    	 
    	  ApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"/com/mphasis/springday1/config.xml"});  // IOC container
        
    	  Sim airtelSim1= context.getBean("sim1",Sim.class);
    	  airtelSim1.calling();
    	  airtelSim1.data();
    	  
    	  
    	  Sim airtelSim2 = context.getBean("sim1",Sim.class);
    	  airtelSim2.calling();
    	  airtelSim2.data();
    	   
    	  System.out.println(airtelSim1.hashCode());
    	  System.out.println(airtelSim2.hashCode());
    	  
    	  
    	  
    	  Sim sim2 = context.getBean("sim2",Sim.class);
    	  sim2.calling();
    	  sim2.data();
    	  
    	  
    }
}

// Spring Framework provides  - IOC - Inversion of Control
 // 1. Object creation
 // 2. Management of Objects 
