package com.mphasis.springday1;

public class Vodafone implements Sim {

	public void calling() {
		
		System.out.println("Calling from Vodafone N/W");
	}

	public void data() {
		
		System.out.println("Using data of Vodafone N/W");
	}

}
